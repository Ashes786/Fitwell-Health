import { NextResponse } from 'next/server'
import { main } from '@/lib/seed'

export async function GET() {
  try {
    await main()
    return NextResponse.json({ message: 'Database seeded successfully' })
  } catch (error) {
    console.error('Error seeding database:', error)
    return NextResponse.json({ error: 'Failed to seed database' }, { status: 500 })
  }
}