export default function TestPage() {
  return (
    <div>
      <h1>Test Page</h1>
      <p>If you can see this, the basic setup is working.</p>
    </div>
  )
}