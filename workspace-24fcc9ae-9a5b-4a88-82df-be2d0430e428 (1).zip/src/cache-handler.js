// Simple cache handler for Next.js incremental cache
export default async function incrementalCacheHandler() {
  return {
    // Return empty cache handler for now
    // This can be extended with proper caching logic later
  }
}